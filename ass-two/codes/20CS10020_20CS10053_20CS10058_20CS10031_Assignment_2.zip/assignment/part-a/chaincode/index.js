"use strict";

const myContract = require("./contract");

module.exports.contracts = [myContract];
